CTRL + SHIFT + I 

On Omegle.com

Then paste in console and click enter. It will then show their IP's with VIDEO ONLY